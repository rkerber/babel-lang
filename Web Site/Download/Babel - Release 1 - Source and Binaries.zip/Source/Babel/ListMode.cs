using System;

namespace Babel
{
    public enum ListMode
    {
        And,
        Or
    }
}