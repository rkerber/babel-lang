using System;

namespace Babel
{
    public enum Tense
    {
        Present,
        Past,
        Future
    }
}